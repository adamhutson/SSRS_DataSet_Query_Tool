﻿namespace SSRS_DataSet_Query_Tool
{
    internal class ReportDataSet
    {
        public string DataSetName { get; set; }
        public string Query { get; set; }
    }
}
